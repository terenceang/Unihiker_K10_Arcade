#ifndef _EMULATION_H_
#define _EMULATION_H_

#ifdef ENABLE_DKONG
#define DKONG_AUDIO_QUEUE_LEN   16
#define DKONG_AUDIO_QUEUE_MASK (DKONG_AUDIO_QUEUE_LEN-1)

extern unsigned char dkong_audio_transfer_buffer[DKONG_AUDIO_QUEUE_LEN][64];
extern unsigned char dkong_audio_rptr, dkong_audio_wptr;
#endif

// Button bitmask values — must match K10_BUTTON_* in hardware/k10_input.h.
#define BUTTON_LEFT  0x01
#define BUTTON_RIGHT 0x02
#define BUTTON_UP    0x04
#define BUTTON_DOWN  0x08
#define BUTTON_FIRE  0x10
#define BUTTON_START 0x20
#define BUTTON_COIN  0x40
#define BUTTON_EXTRA 0x80

#ifndef SINGLE_MACHINE
// These values are pinned to match K10Machine in k10_state.h so that
// the 'machine' global (set from K10Machine) correctly matches MCH_* in
// switch() dispatches regardless of which games are compiled in.
enum {
      MCH_MENU    = 0,
      MCH_PACMAN  = 1,
      MCH_GALAGA  = 2,
      MCH_DKONG   = 3,
      MCH_FROGGER = 4,
      MCH_DIGDUG  = 5,
      MCH_1942    = 6,
      MCH_LAST    = 7,
};

#define MACHINES  (MCH_LAST-1)
#endif

// wrapper around machine specific code sections allowing to compile only
// code in that's needed for enabled machines

#ifdef ENABLE_PACMAN
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_PACMAN  1
    #define PACMAN_BEGIN
    #define PACMAN_END
  #else
    #define MACHINE_IS_PACMAN  (machine == MCH_PACMAN)
    // pacman is always the first entry
    #define PACMAN_BEGIN  if(machine == MCH_PACMAN) {
    #define PACMAN_END    }
  #endif
#endif

#ifdef ENABLE_GALAGA
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_GALAGA  1
    #define GALAGA_BEGIN
    #define GALAGA_END
  #else
    #define MACHINE_IS_GALAGA  (machine == MCH_GALAGA)
    // galaga is not the first if pacman is enabled
    #ifdef ENABLE_PACMAN
      // donkey kong, frogger, digdug or 1942 may come afterwards
      #if defined(ENABLE_DKONG) || defined(ENABLE_FROGGER) || defined(ENABLE_DIGDUG) || defined(ENABLE_1942)
        #define GALAGA_BEGIN  else if(machine == MCH_GALAGA) {
      #else
        #define GALAGA_BEGIN  else {
      #endif
    #else
      #define GALAGA_BEGIN  if(machine == MCH_GALAGA) {
    #endif
    #define GALAGA_END    }
  #endif
#endif

#ifdef ENABLE_DKONG
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_DKONG  1
    #define DKONG_BEGIN
    #define DKONG_END
  #else
    #define MACHINE_IS_DKONG  (machine == MCH_DKONG)
    // dkong is not the first if pacman or galaga are enabled
    #if defined(ENABLE_PACMAN) || defined(ENABLE_GALAGA)
      // frogger, digdug or 1942 may come afterwards
      #if defined(ENABLE_FROGGER) || defined(ENABLE_DIGDUG) || defined(ENABLE_1942)
        #define DKONG_BEGIN  else if(machine == MCH_DKONG) {
      #else
        #define DKONG_BEGIN  else {
      #endif
    #else
      #define DKONG_BEGIN  if(machine == MCH_DKONG) {
    #endif
    #define DKONG_END    }
  #endif
#endif

#ifdef ENABLE_FROGGER
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_FROGGER  1
    #define FROGGER_BEGIN
    #define FROGGER_END
  #else
    #define MACHINE_IS_FROGGER  (machine == MCH_FROGGER)
    // frogger is not the first if pacman, galaga or dkong are enabled
    #if defined(ENABLE_PACMAN) || defined(ENABLE_GALAGA) || defined(ENABLE_DKONG)
      // digdug or 1942 may come afterwards
      #if defined(ENABLE_DIGDUG) || defined(ENABLE_1942)
        #define FROGGER_BEGIN  else if(machine == MCH_FROGGER) {
      #else
        #define FROGGER_BEGIN  else {
      #endif
    #else
      #define FROGGER_BEGIN  if(machine == MCH_FROGGER) {
    #endif
    #define FROGGER_END    } 
  #endif
#endif

#ifdef ENABLE_DIGDUG
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_DIGDUG  1
    #define DIGDUG_BEGIN
    #define DIGDUG_END
  #else
    #define MACHINE_IS_DIGDUG  (machine == MCH_DIGDUG)
    // digdug is not the first if pacman, galaga, dkong or frogger are enabled
    #if defined(ENABLE_PACMAN) || defined(ENABLE_GALAGA) || defined(ENABLE_DKONG) || defined(ENABLE_FROGGER)
      // 1942 may come afterwards
      #if defined(ENABLE_1942)
        #define DIGDUG_BEGIN  else if(machine == MCH_DIGDUG) {
      #else
        #define DIGDUG_BEGIN  else {
      #endif
    #else
      #define DIGDUG_BEGIN  if(machine == MCH_DIGDUG) {
    #endif
    #define DIGDUG_END    } 
  #endif
#endif

#ifdef ENABLE_1942
  #ifdef SINGLE_MACHINE
    #define MACHINE_IS_1942  1
    #define _1942_BEGIN
    #define _1942_END
  #else
    #define MACHINE_IS_1942  (machine == MCH_1942)
    // digdug is never first and always last
    #define _1942_BEGIN  else {
    #define _1942_END    }
  #endif
#endif

#if defined(__cplusplus)
extern "C"
{
#endif
void prepare_emulation(void);
void emulate_frame(void);
extern unsigned char *memory;
extern char game_started;
extern const unsigned char *current_rom_base;
#ifdef ENABLE_GALAGA
extern unsigned char starcontrol;
#endif
#if defined(ENABLE_GALAGA) || defined(ENABLE_PACMAN) || defined(ENABLE_DIGDUG) || defined(ENABLE_FROGGER) || defined(ENABLE_1942)
extern unsigned char soundregs[32];
#endif
#ifndef SINGLE_MACHINE
extern signed char machine;
extern signed char menu_sel;
#endif
#ifdef ENABLE_DKONG
extern unsigned char colortable_select;
extern void audio_dkong_bitrate(char);
#endif

#ifndef SINGLE_MACHINE
extern void emulation_reset(void);

#ifdef MASTER_ATTRACT_MENU_TIMEOUT
extern unsigned long master_attract_timeout;
#endif
#endif

// external functions called by emulation
#ifdef ENABLE_GALAGA
extern void galaga_trigger_sound_explosion(void);
#endif
#ifdef ENABLE_DKONG
extern void dkong_trigger_sound(char);   // 0..15 = sfx, 16.. = mus
#endif
extern unsigned char buttons_get(void);
#if defined(__cplusplus)
}
#endif

/* ------------------ the following is used inside Z80.c ----------------- */
extern char current_cpu;
#ifdef ENABLE_PACMAN
extern const unsigned char pacman_rom[];
#endif
#ifdef ENABLE_GALAGA
extern const unsigned char galaga_rom_cpu1[];
extern const unsigned char galaga_rom_cpu2[];
extern const unsigned char galaga_rom_cpu3[];
#endif
#ifdef ENABLE_DKONG
extern const unsigned char dkong_rom_cpu1[];
#endif
#ifdef ENABLE_FROGGER
extern const unsigned char frogger_rom_cpu1[];
extern const unsigned char frogger_rom_cpu2[];
#endif
#ifdef ENABLE_DIGDUG
extern const unsigned char digdug_rom_cpu1[];
extern const unsigned char digdug_rom_cpu2[];
extern const unsigned char digdug_rom_cpu3[];
#endif
#ifdef ENABLE_1942
extern unsigned char _1942_bank;
extern unsigned char _1942_sound_latch;
extern const unsigned char _1942_rom_cpu1[];
extern const unsigned char _1942_rom_cpu2[];
extern const unsigned char _1942_rom_cpu1_b0[];
extern const unsigned char _1942_rom_cpu1_b1[];
extern const unsigned char _1942_rom_cpu1_b2[];
#endif

#define NONE  ((const unsigned char *)0l)

#ifndef IO_EMULATION
#ifdef ENABLE_1942
static inline byte OpZ80_1942_INL(register word Addr) {
  static const unsigned char *_1942_bank_table[] = {
    _1942_rom_cpu1_b0, _1942_rom_cpu1_b1, _1942_rom_cpu1_b2
  };

  if(current_cpu == 0) {
    if(Addr < 0x8000) return _1942_rom_cpu1[Addr];
    if((Addr & 0xc000) == 0x8000) {
      if(_1942_bank == 0) return _1942_bank_table[0][Addr - 0x8000];
      if((_1942_bank == 1) && (Addr < 0xb000)) return _1942_bank_table[1][Addr - 0x8000];
      if(_1942_bank == 2) return _1942_bank_table[2][Addr - 0x8000];
    }

    if((Addr & 0xf000) == 0xe000) return memory[Addr - 0xe000];
    if((Addr & 0xff80) == 0xcc00) return memory[Addr - 0xcc00 + 0x2400];
    if((Addr & 0xf800) == 0xd000) return memory[Addr - 0xd000 + 0x1000];
    if((Addr & 0xfc00) == 0xd800) return memory[Addr - 0xd800 + 0x2000];
  } else {
    if(Addr < 0x4000) return _1942_rom_cpu2[Addr];
    if((Addr & 0xf800) == 0x4000) return memory[Addr - 0x4000 + 0x1800];
    if(Addr == 0x6000) return _1942_sound_latch;
  }

  return current_rom_base[Addr];
}
#endif

static inline byte OpZ80_INL(register word Addr) {
#ifdef ENABLE_1942
  if(MACHINE_IS_1942) return OpZ80_1942_INL(Addr);
#endif
  
  return current_rom_base[Addr];
}
#endif // IO_EMULATION

#endif // _EMULATION_H_
